import React from 'react'

const PlansPage = () => {
  return (
    <div>PlansPage</div>
  )
}

export default PlansPage