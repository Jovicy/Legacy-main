import React from "react";

const Help = () => {
  return (
    <section className="py-20">
      <div className="custom-container flex flex-col gap-10">
        {/* Title */}
        <div></div>
        {/* content */}
        <div>
          <div className="w-1/2"></div>
        </div>
      </div>
    </section>
  );
};

export default Help;
